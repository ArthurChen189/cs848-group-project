import pandas as pd

parent_table = pd.read_csv('./datasets/raw/rossmann/store.csv')
train_table = pd.read_csv('./datasets/raw/rossmann/train.csv')
test_table = pd.read_csv('./datasets/raw/rossmann/test.csv')

# we only keep data after 2015-06-01
train_table = train_table[train_table['Date'] >= '2015-06-01']
test_table = test_table[test_table['Date'] >= '2015-06-01']

train_table.to_csv('./datasets/preprocessed/rossmann/rossmann_train.csv', index=False)
test_table.to_csv('./datasets/preprocessed/rossmann/rossmann_test.csv', index=False)
parent_table.to_csv('./datasets/preprocessed/rossmann/rossmann_parent.csv', index=False)
